$(document).ready(function() {
    $('table').addClass('table table-striped table-hover');
});
